def main():
    return "Hi!"